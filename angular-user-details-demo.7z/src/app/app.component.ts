import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angular-user-details-demo';
  showFormFlag: boolean= false;
  constructor(private router: Router) {}

  navigate() {
    this.router.navigate(["/user-details-form"]);
    this.showFormFlag = true;
  }
 
}
