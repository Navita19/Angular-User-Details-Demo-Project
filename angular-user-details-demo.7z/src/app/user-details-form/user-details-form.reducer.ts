import { UserDetails } from './user-details-form.model';
import { Action } from '@ngrx/store';
export const add_details = 'add_details';
export function addDetailsReducer(state: UserDetails[] = [], action) {
  switch (action.type) {
    case add_details:
        return [...state, action.payload];
    default:
        return state;
    }
}