export interface UserDetails{
    firstName:string;
    lastName:string;
    email:string;
    budget:string;
    phno:number;
}