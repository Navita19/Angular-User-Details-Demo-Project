import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { UserDetails } from './user-details-form.model';
import { Observable } from 'rxjs';
import { AppState } from './../app.state';
import { Message } from 'primeng/api';

@Component({
  selector: 'app-user-details-form',
  templateUrl: './user-details-form.component.html',
  styleUrls: ['./user-details-form.component.scss'],
})
export class UserDetailsFormComponent implements OnInit {
  firstNameErrorFlag: boolean = false;
  lastNameErrorFlag: boolean = false;
  emailErrorFlag: boolean = false;
  budgetErrorFlag: boolean = false;
  phnoErrorFlag: boolean = false;
  firstName: string;
  phno: number;
  budget: string;
  email: string;
  lastName: string;
  showMandatoryFlag: boolean = false;
  userDetail: Observable<UserDetails[]>;
  allDetails: any = [];
  msgs1: Message[];

  constructor(private store: Store<AppState>) {
    this.userDetail = this.store.select(state => state.userDetails);
  }

  addUserDetails(firstName, lastName, phno, budget, email) {
    this.store.dispatch({
      type: 'add_details',
      payload: <UserDetails>{
        firstName: firstName,
        lastName: lastName,
        phno: phno,
        budget: budget,
        email: email
      }
    });
    if ((this.firstName === undefined || this.firstName === "") ||
      (this.lastName === undefined || this.lastName === "") ||
      (this.email === undefined || this.email === "") ||
      (this.budget === undefined || this.budget === "") ||
      (this.phno === undefined || this.phno === 0)) {
      this.showMandatoryFlag = true;
      this.firstNameErrorFlag = false;
      this.lastNameErrorFlag = false;
      this.phnoErrorFlag = false;
      this.budgetErrorFlag = false;
      this.emailErrorFlag = false;
    }
    else if (this.firstNameErrorFlag == true || this.lastNameErrorFlag == true || this.phnoErrorFlag == true || this.budgetErrorFlag == true || this.emailErrorFlag == true) {
      this.msgs1 = [{ severity: 'error', summary: 'Fill the required Field with Correct pattern', detail: '' }];
    }
    else if (this.allDetails != []) {
      this.allDetails = {
        "firstName": firstName,
        "lastName": this.lastName,
        "email": this.email,
        "budget": this.budget,
        "phno": this.phno
      }
      this.msgs1 = [{ severity: 'success', summary: 'All data of User is successfully displaying on table', detail: '' }];
     this.firstName = "";
     this.lastName = "";
     this.budget = "";
     this.email = "";
     this.phno = 0;

    }
  }


  ngOnInit(): void {
  }

  validateFirstName(val) {
    if (val) {
      let pattern = /^[A-Za-z]+$/;
      let k = pattern.test(val);
      // tslint:disable-next-line: triple-equals
      if (k == false) {
        this.firstNameErrorFlag = true;
      } else {
        this.firstNameErrorFlag = false;
      }
    }
  }
  validateLastName(val) {
    if (val) {
      let pattern = /^[A-Za-z]+$/;
      let k = pattern.test(val);
      // tslint:disable-next-line: triple-equals
      if (k == false) {
        this.lastNameErrorFlag = true;
      } else {
        this.lastNameErrorFlag = false;
      }
    }
  }
  validateEmail(val) {
    if (val) {
      let pattern = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      let k = pattern.test(val);
      // tslint:disable-next-line: triple-equals
      if (k == false) {
        this.emailErrorFlag = true;
      } else {
        this.emailErrorFlag = false;
      }
    }
  }
  validateBudget(val) {
    if (val) {
      let pattern = /[0-9]+$/;
      let k = pattern.test(val);
      // tslint:disable-next-line: triple-equals
      if (k == false) {
        this.budgetErrorFlag = true;
      } else {
        this.budgetErrorFlag = false;
      }
    }
  }
  validatePhno(val) {
    if (val) {
      let pattern = /[0-9]{10}/;
      let k = pattern.test(val);
      // tslint:disable-next-line: triple-equals
      if (k == false) {
        this.phnoErrorFlag = true;
      } else {
        this.phnoErrorFlag = false;
      }
    }
  }

}
