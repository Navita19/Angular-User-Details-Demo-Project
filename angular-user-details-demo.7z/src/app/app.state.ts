import { UserDetails } from './user-details-form/user-details-form.model';
export interface AppState {
  readonly userDetails: UserDetails[];
}