import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserDetailsFormComponent } from './user-details-form/user-details-form.component';
import { AppComponent } from './app.component';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([
    {path: 'user-details-form', component: UserDetailsFormComponent},
   { path: 'home', component: AppComponent},
    
    {path: "", redirectTo: 'home', pathMatch: 'prefix'},
  ]),
],
  exports: [RouterModule]
})
export class AppRoutingModule { }