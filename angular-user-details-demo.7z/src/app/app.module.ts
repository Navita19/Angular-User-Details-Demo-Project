import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserDetailsFormComponent } from './user-details-form/user-details-form.component';
import {CardModule} from 'primeng/card';
import {InputTextModule} from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import {KeyFilterModule} from 'primeng/keyfilter';
import { FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { addDetailsReducer } from './user-details-form/user-details-form.reducer';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';





@NgModule({
  declarations: [
    AppComponent,
    UserDetailsFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CardModule,
    InputTextModule,
    ButtonModule,
    KeyFilterModule,
    FormsModule,
    MessagesModule,
    MessageModule,
    BrowserAnimationsModule,
    StoreModule.forRoot({product: addDetailsReducer})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
